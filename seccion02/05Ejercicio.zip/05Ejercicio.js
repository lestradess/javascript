const datos = [
    "Jose",
    48,
    true,
    new Date(1975, 9, 24),
    {
        titulo: "Código limpio",
        autor: "Robert C. Martín",
        fecha: new Date(2012, 6, 19),
        url: "https://anayamultimedia.es/libro/programacion/codigo-limpio-robert-c-martin-9788441532106/"
    },
];